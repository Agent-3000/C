/**********************************
Name: Jalen Jones
Date: October 13, 2022
Program: Stacks.cpp
Description: This program will demonstrate how a stack list works.
*********************************/
#include<iostream>

using namespace std;

class Node
{
public:
	int data;
	Node * next;

	//Constructor
	Node() : data(0), next(nullptr) {}
	Node(int data) : data(data), next(nullptr) {}
	Node(int data, Node* next) :
		data(data), next(next) {}

		
};
class Stack
{
private: 
	Node* top;

public:
	Stack() : top(nullptr) {}

	void push(int data);
	bool pop();
	bool peek(int& data);
	void display();

};
void Stack::push(int data)
{
	Node* tmp = new Node(data);

	tmp->next = top;
	top = tmp;
}
bool Stack::pop()
{
	Node* tmp = top;
	if (top == nullptr) return false;

	top = top->next;
	delete tmp;
	return true;
}
bool Stack::peek(int& data)
{
	if (top == nullptr)return false;
	data = top->data;
	return true;
}
void Stack::display()
{
	Node* tmp = top;

	while (tmp != nullptr)
	{
		cout << tmp->data << " ";
		tmp = tmp->next;
	}
	cout << endl;
}
int main()
{
	Stack S;
	int tmp;
	S.push(5);
	S.peek(tmp);
	cout << tmp << endl;
	S.push(33);
	S.push(1);
	S.push(7);
	S.peek(tmp);
	cout << tmp << endl;
	S.push(33);
	S.push(12);
	S.display();
	S.pop();
	S.display();
	S.push(14);
	S.display();
	S.pop();
	S.pop();
	S.display();
	S.pop();
	S.pop();
	S.display();
	S.peek(tmp);
	cout << tmp << endl;
	
}